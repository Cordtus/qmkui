qmk compile -kb keychron/v5_max/ansi_encoder -km qmkui_test
qmk flash -kb keychron/v5_max/ansi_encoder -km qmkui_test
